
import {Recipe} from './recipe.model';

export class RecipesResponse {

  public code: string ;
  public description: string;
  public recipes: Recipe[];

}
